# Sprint 2: Manuscript Captions

## Figure Captions

**Figure 1. Annual mean hydrological response to SMAP assimilation (2016–2020)**
*Caption:* Spatial distribution of the annual mean hydrological response to SMAP assimilation over northern Morocco (2016–2020). The panels display the differences for DA-NoCDF minus Open Loop (OPL) (top row), DA-CDF minus OPL (middle row), and DA-NoCDF minus DA-CDF (bottom row). Variables include surface soil moisture ($\Delta$SSM), root-zone soil moisture ($\Delta$RZSM), evapotranspiration ($\Delta$ET), total runoff ($\Delta$Total runoff), surface runoff ($\Delta$Surface runoff), and baseflow ($\Delta$Baseflow). Fluxes are expressed in mm/day and state variables in m$^3$/m$^3$. Divergent colorbars are centered on zero, with red (blue) indicating a decrease (increase) relative to the baseline. Note: CDF matching strongly attenuates the runoff/baseflow response relative to DA-NoCDF. This baseflow response acts as a diagnostic of deep buffering and should not be interpreted as improved streamflow prior to explicit routing.

**Figure 2. Winter (DJF) mean hydrological response to SMAP assimilation (2016–2020)**
*Caption:* Spatial distribution of the winter (DJF) mean hydrological response to SMAP assimilation (2016–2020). The panel structure and variables are identical to Figure 1. During DJF, DA-NoCDF suggests a widespread drying effect across the domain, heavily modifying both soil moisture states and the ensuing baseflow. Colorbar limits are kept identical to the annual figure to allow magnitude comparisons.

**Figure 3. Summer (JJA) mean hydrological response to SMAP assimilation (2016–2020)**
*Caption:* Spatial distribution of the summer (JJA) mean hydrological response to SMAP assimilation (2016–2020). The panel structure and variables are identical to Figure 1. During JJA, DA-NoCDF is associated with a slight wetting effect compared to the OPL, suggesting the model background is marginally too dry compared to the satellite retrievals. Colorbar limits are kept identical to the annual figure to allow magnitude comparisons.

**Figure 4. First-order water-balance diagnostic (2016–2020)**
*Caption:* First-order water-balance diagnostic (Precipitation minus ET minus Total Runoff) for the Open Loop (OPL), DA-NoCDF, and DA-CDF experiments across annual, DJF, and JJA periods. Fluxes are expressed in mm/day. The flux-only balance provides a first-order interpretability check, but does not demonstrate exact water-balance closure because temporal storage changes ($\Delta$S) are not explicitly included. The residual changes introduced by DA-NoCDF highlight where assimilation dynamically adds or removes unmodeled water.

**Figure 5. Precipitation and runoff components under DA-NoCDF (2016–2020)**
*Caption:* Annual mean precipitation and runoff partitioning (Total Runoff and Baseflow) for the DA-NoCDF experiment (2016–2020). Precipitation forcing is exclusively sourced from IMERG, expressed in mm/day. The runoff response is strongly dominated by the baseflow-like component in the pre-routing Noah-MP outputs.

**Figure 6. Precipitation and runoff components under DA-CDF (2016–2020)**
*Caption:* Annual mean precipitation and runoff partitioning (Total Runoff and Baseflow) for the DA-CDF experiment (2016–2020). Precipitation forcing is sourced from IMERG, expressed in mm/day. Note: The weak color contrast in runoff compared to DA-NoCDF indicates a small response relative to the NoCDF experiment, not missing data, reflecting the strong attenuation caused by CDF matching.
